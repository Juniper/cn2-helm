#!/bin/bash
echo "Deleting CN2 objects"
echo "kubectl delete jobs coredns-deployment-update-init-test -n contrail"
kubectl delete jobs coredns-deployment-update-init-test -n contrail
echo "kubectl delete -f configplane.juniper.net_contrailcertificatemanagers.yaml"
kubectl delete -f configplane.juniper.net_contrailcertificatemanagers.yaml
echo "kubectl delete -f contrail.yaml"
kubectl delete -f contrail.yaml
echo "kubectl delete gvc default-global-vrouter-config"
kubectl delete gvc default-global-vrouter-config
echo "kubectl delete gsc default-global-system-config"
kubectl delete gsc default-global-system-config
echo "kubectl delete -f contrail_system.yaml"
kubectl delete -f contrail_system.yaml
echo "kubectl delete -f deployer.yaml"
kubectl delete -f deployer.yaml
echo "kubectl delete -f configplane.juniper.net_apiservers.yaml"
kubectl delete -f configplane.juniper.net_apiservers.yaml
echo "kubectl delete -f controlplane.juniper.net_controls.yaml"
kubectl delete -f controlplane.juniper.net_controls.yaml
echo "kubectl delete -f configplane.juniper.net_controllers.yaml"
kubectl delete -f configplane.juniper.net_controllers.yaml
echo "kubectl delete -f configplane.juniper.net_kubemanagers.yaml"
kubectl delete -f configplane.juniper.net_kubemanagers.yaml
echo "kubectl delete -f dataplane.juniper.net_vrouters.yaml"
kubectl delete -f dataplane.juniper.net_vrouters.yaml
echo "kubectl delete -f k8s.cni.cncf.io_network-attachment-definitions.yaml"
kubectl delete -f k8s.cni.cncf.io_network-attachment-definitions.yaml
echo "Cleanup any contrail namespaces stuck in Terminating state"
for ns in $(kubectl get ns --field-selector status.phase=Terminating -o jsonpath='{.items[*].metadata.name}')
do
	  kubectl get ns $ns -ojson | jq '.spec.finalizers = []' | kubectl replace --raw "/api/v1/namespaces/$ns/finalize" -f -
  done

  for ns in $(kubectl get ns --field-selector status.phase=Terminating -o jsonpath='{.items[*].metadata.name}')
  do
	    kubectl get ns $ns -ojson | jq '.metadata.finalizers = []' | kubectl replace --raw "/api/v1/namespaces/$ns/finalize" -f -
    done
echo "Uninstall CN2 complete"
echo "If contrail-readiness is deployed, please delete it now"
